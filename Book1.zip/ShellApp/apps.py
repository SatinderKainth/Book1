from django.apps import AppConfig


class ShellappConfig(AppConfig):
    name = 'ShellApp'
